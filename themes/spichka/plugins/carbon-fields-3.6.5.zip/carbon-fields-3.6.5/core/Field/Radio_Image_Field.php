<?php

namespace Carbon_Fields\Field;

/**
 * Radio buttons field class.
 */
class Radio_Image_Field extends Select_Field {

}
