/**
 * External dependencies.
 */
import { createContext } from '@wordpress/element';

export const { Provider, Consumer } = createContext( false );
