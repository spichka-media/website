/**
 * Internal dependencies.
 */
import base from './base';

export default {
	...base,

	/**
	 * @inheritdoc
	 */
	getEnvironmentValue() {
		return true;
	}
};
