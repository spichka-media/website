<h2><?php echo $this->title; ?></h2>

<table class="form-table">
	<tbody>
		<tr>
			<th></th>
			<td>
				<fieldset class="container-<?php echo $this->get_id(); ?>" data-profile-role="<?php echo $profile_role ?>"></fieldset>
			</td>
		</tr>
	</tbody>
</table>
