<?php
$container_css_class = 'theme-options';
require( 'common/options-page.php' );
